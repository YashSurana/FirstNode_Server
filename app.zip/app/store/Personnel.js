Ext.define('Test.store.Personnel', {
    extend: 'Ext.data.Store',

    alias: 'store.personnel',

    fields: [
        'name', 'email', 'phone'
    ],
	sorters: 'name',

   grouper: {
       groupFn: function(record) {
           return record.get('name')[0];
       }
   },
    data: { items: [
        { name: 'Jean Luc', email: "jeanluc.picard@enterprise.com", phone: "http://assets.en.oreilly.com/1/eventprovider/1/_@user_6262.jpg" },
        { name: 'Worf',     email: "worf.moghsson@enterprise.com",  phone: "http://assets.en.oreilly.com/1/eventprovider/1/_@user_60981.jpg" },
        { name: 'Deanna',   email: "deanna.troi@enterprise.com",    phone: "http://assets.en.oreilly.com/1/eventprovider/1/_@user_251.jpg" },
        { name: 'Data',     email: "mr.data@enterprise.com",        phone: "http://assets.en.oreilly.com/1/eventprovider/1/_@user_102517.jpg" }
    ]},

    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    }
});
