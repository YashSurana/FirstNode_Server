Ext.define('Test.view.MyViewCarouseController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.myviewcarouse',
    
	onInitialize : function(view, eopts){
		//debugger;
		var store = Ext.getStore('Personnel');
		console.log(store.data.items[0].data.name+view);
		var carouselpages=[];
		console.log(carouselpages);
		for (i=0;i<store.getCount();i++){
			console.log(i);
			var carouselpage=Ext.create('Ext.Component',{
				cls:'carouselpage',
				html: '<div><img width="300" src="'+store.getAt(i).get("phone")+'" /><p>'+store.getAt(i).get("name")+'</p></div>'
				//html:'<p> Yash'+store.getAt(i).get("phone")+'</p>'
			});
			console.log(carouselpage);
			carouselpages.push(carouselpage);
		}
		var carousel = this.getView().down('#myCarousel');
	carousel.add(carouselpages);
	},
	next : function(){
		console.log('hello');
		console.log(this.getView());
		this.getView().down('#myCarousel').next();
		var store = Ext.getStore('Personnel');
		if(this.getView().down('#myCarousel').getActiveIndex() ==3){
			this.getView().down('#myCarousel').setActiveItem(0)
		}
	}
});
