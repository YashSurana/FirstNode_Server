Ext.define('Test.view.MyViewCarouseModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.myviewcarouse',
	fields: ['id', 'name'],

   data: {
	   items:[
                {id:1, name:'Page 1'},
                {id:2, name:'Page 2'},
                {id:3, name:'Page 3'},
                {id:4, name:'Page 4'},
                {id:5, name:'Page 5'}
            ]
		}
});
