
Ext.define('Test.view.MyViewCarouse',{
    extend: 'Ext.Panel',
	itemId:'mycarousel',
    requires: [
        'Test.view.MyViewCarouseController',
        'Test.view.MyViewCarouseModel',
        'Test.store.Personnel'
    ],
	layout : 'hbox',
	height : '100%',
    controller: 'myviewcarouse',
    viewModel: {
        type: 'myviewcarouse'
    },
    store: {
        type: 'personnel'
    },

    defaults: {
        styleHtmlContent: true
    },
	
	listeners : {
		initialize : 'onInitialize'
	},
	items:[{
		xtype:'carousel',
		itemId:'myCarousel',
		showIndicators : true,
		style:{
			margin:'20px',
			textAlign:'center'
		},
		flex : 1,
		border : 1
	},{
		xtype:'button',
		text:'next',
		ui:'action',
		layout:{
			type:'hbox',
				align:'center'
		},
		handler: 'next'
		
		},{
			xtype:'list',
			store:'Personnel',
			flex:1,
			grouped:true,
			itemTpl:'{name} is {email}'
		}]

    
});
