/**
 * This view is an example list of people.
 */
Ext.define('Test.view.main.List', {
    extend: 'Ext.DataView',
    xtype: 'mainlist',

    requires: [
        'Test.store.Personnel'
    ],
	inline:true,
    title: 'Personnel',

    store: {
        type: 'personnel'
    },

    listeners: {
        select: 'onItemSelected'
    },
	itemTpl:'{name}'
});
